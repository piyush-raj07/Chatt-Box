var express = require('express');
var bodyParser = require('body-parser');
var multer = require('multer');
var upload = multer();
var app = express();
var mysql = require('mysql');
var session = require('express-session');
var mysql=require('mysql');

var con=mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "ChattApp"
})

con.connect(function(err){
    console.log("connected");
})
app.use(session({
  secret: "Shh, its a secret!",
  resave: false,
  saveUninitialized: false
}));

app.set('view engine', 'ejs');
app.set('views', './views');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(upload.array());
app.use(express.static('public'));

app.get('/index', function(req, res) {
  res.render('index');
});

app.get('/register', function(req, res) {
    res.render('register');
  });

app.post('/logindata',function(req,res){
    
    if(req.body.ChattApp==='login')
        {
            var sql="select username,password from login where username'"+req.body.username+"' and password='"+req.body.password+"' ";
            con.query(sql,function(err,result){
                if(err) throw err;
                if(result.length>0){
                    res.render('search');
                }
                else{
                    res.render('error');
                }
            });
        }
});

app.post('/register',function(req,res){
      
    if(req.body.ChattApp === 'login')
        {
          var sql="insert into login values('"+req.body.username+"','"+req.body.password+"')";
          con.query(sql,function(err)
          {
              if(err) throw err;
              console.log("1 record inserted");
              res.render('index');
          });
        }
});

app.listen(3000);