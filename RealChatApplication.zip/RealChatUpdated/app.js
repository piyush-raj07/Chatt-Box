var express = require('express');
var bodyParser = require('body-parser');
var multer = require('multer');
var upload = multer();
var app = express();
var mysql = require('mysql');
var session = require('express-session');
var mysql=require('mysql');

var con=mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "chatt"
})

con.connect(function(err){
    console.log("connected");
})
app.use(session({
  secret: "Shh, its a secret!",
  resave: false,
  saveUninitialized: false
}));

app.set('view engine', 'ejs');
app.set('views', './views');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(upload.array());
app.use(express.static('public'));

app.get('/index', function(req, res) {
  res.render('index');
});

app.get('/register', function(req, res) {
    res.render('register');
  });

  app.post('/logindata', function(req, res) {
    var email = req.body.email;
    var password = req.body.password;

    var sql = "SELECT username,password FROM login WHERE username = ? AND password = ?";
    con.query(sql, [email, password], function(err, result) {
        if (err) throw err;
        if (result.length > 0) {
            res.render('search');
        } else {
            res.render('error');
        }
    });
});


app.post('/register',function(req,res){
    var email = req.body.email;
    var password = req.body.password;
    
    var sql = "INSERT INTO login (username, password) VALUES (?, ?)";
    con.query(sql, [email, password], function(err) {
        if(err) throw err;
        console.log("1 record inserted");
        res.render('index');
    });
});


var server = app.listen(3000, function() {
    console.log('Server listening on port 3000');
});

var socketIo = require('socket.io');

// Initialize Socket.IO
var io = socketIo(server);

// Socket.IO logic for real-time chat

io.on('connection', function(socket) {
    console.log('A user connected');

    // Get the username from the client
    var username = '';
    var timeoutId; // Variable to store the timeout ID

    socket.on('set-username', function(name) {
        username = name;
    });

    socket.on('disconnect', function() {
        console.log('User disconnected');
        // Emit user-disconnected event to all connected clients along with the username
        io.emit('user-disconnected', username.toUpperCase() + ': DISCONNECTED');
        clearTimeout(timeoutId); // Clear the timeout if the user disconnects
        
    });

    // Handle chat messages
    socket.on('chat-message', function(message) {
        console.log('message: ' + message);
        // Broadcast the message to all connected clients along with the sender's username
        io.emit('chat-message', username.toUpperCase() + ': ' + message);

        clearTimeout(timeoutId)
        timeoutId = setTimeout(function() {
            console.log('Timeout reached');
            io.emit('user-unavailable', username.toUpperCase()+' is not available');
            
        }, 10000);

    });

    // Set a timeout to emit a message if the user is not responding within 10 seconds
  

});